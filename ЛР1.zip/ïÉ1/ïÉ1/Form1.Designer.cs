﻿namespace ЛР1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new System.Windows.Forms.MenuStrip();
            toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            createToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            cancelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            repeatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            insertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            formulationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            grammarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            grammarClassificationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            analysisMethodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            errorNeutralizationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            testCaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            bibliographyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            callHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            aboutProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            toolStrip1 = new System.Windows.Forms.ToolStrip();
            createFileButton = new System.Windows.Forms.ToolStripButton();
            openFileButton = new System.Windows.Forms.ToolStripButton();
            saveFileButton = new System.Windows.Forms.ToolStripButton();
            cancelChangeButton = new System.Windows.Forms.ToolStripButton();
            repeatLastChangeButton = new System.Windows.Forms.ToolStripButton();
            copyTextButton = new System.Windows.Forms.ToolStripButton();
            cutTextButton = new System.Windows.Forms.ToolStripButton();
            insertTextButton = new System.Windows.Forms.ToolStripButton();
            runParserButton = new System.Windows.Forms.ToolStripButton();
            informationButton = new System.Windows.Forms.ToolStripButton();
            createdByButton = new System.Windows.Forms.ToolStripButton();
            splitContainer1 = new System.Windows.Forms.SplitContainer();
            editingTextBox = new System.Windows.Forms.RichTextBox();
            lexemeTable = new System.Windows.Forms.DataGridView();
            outputTextBox = new System.Windows.Forms.RichTextBox();
            fixButton = new System.Windows.Forms.Button();
            menuStrip1.SuspendLayout();
            toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)lexemeTable).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { toolStripMenuItem1, toolStripMenuItem2, toolStripMenuItem3, toolStripMenuItem5, toolStripMenuItem4 });
            menuStrip1.Location = new System.Drawing.Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            menuStrip1.Size = new System.Drawing.Size(836, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { createToolStripMenuItem, openToolStripMenuItem, saveToolStripMenuItem, saveAsToolStripMenuItem, exitToolStripMenuItem });
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            toolStripMenuItem1.Text = "Файл";
            // 
            // createToolStripMenuItem
            // 
            createToolStripMenuItem.Name = "createToolStripMenuItem";
            createToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            createToolStripMenuItem.Text = "Создать";
            createToolStripMenuItem.Click += createToolStripMenuItem_Click;
            // 
            // openToolStripMenuItem
            // 
            openToolStripMenuItem.Name = "openToolStripMenuItem";
            openToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            openToolStripMenuItem.Text = "Открыть";
            openToolStripMenuItem.Click += openToolStripMenuItem_Click;
            // 
            // saveToolStripMenuItem
            // 
            saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            saveToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            saveToolStripMenuItem.Text = "Сохранить";
            saveToolStripMenuItem.Click += saveToolStripMenuItem_Click;
            // 
            // saveAsToolStripMenuItem
            // 
            saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            saveAsToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            saveAsToolStripMenuItem.Text = "Сохранить как";
            saveAsToolStripMenuItem.Click += saveAsToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            exitToolStripMenuItem.Text = "Выход";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { cancelToolStripMenuItem, repeatToolStripMenuItem, cutToolStripMenuItem, copyToolStripMenuItem, insertToolStripMenuItem, deleteToolStripMenuItem, selectAllToolStripMenuItem });
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new System.Drawing.Size(59, 20);
            toolStripMenuItem2.Text = "Правка";
            // 
            // cancelToolStripMenuItem
            // 
            cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            cancelToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            cancelToolStripMenuItem.Text = "Отменить";
            cancelToolStripMenuItem.Click += cancelToolStripMenuItem_Click;
            // 
            // repeatToolStripMenuItem
            // 
            repeatToolStripMenuItem.Name = "repeatToolStripMenuItem";
            repeatToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            repeatToolStripMenuItem.Text = "Повторить";
            repeatToolStripMenuItem.Click += repeatToolStripMenuItem_Click;
            // 
            // cutToolStripMenuItem
            // 
            cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            cutToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            cutToolStripMenuItem.Text = "Вырезать";
            cutToolStripMenuItem.Click += cutToolStripMenuItem_Click;
            // 
            // copyToolStripMenuItem
            // 
            copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            copyToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            copyToolStripMenuItem.Text = "Копировать";
            copyToolStripMenuItem.Click += copyToolStripMenuItem_Click;
            // 
            // insertToolStripMenuItem
            // 
            insertToolStripMenuItem.Name = "insertToolStripMenuItem";
            insertToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            insertToolStripMenuItem.Text = "Вставить";
            insertToolStripMenuItem.Click += insertToolStripMenuItem_Click;
            // 
            // deleteToolStripMenuItem
            // 
            deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            deleteToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            deleteToolStripMenuItem.Text = "Удалить";
            deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
            // 
            // selectAllToolStripMenuItem
            // 
            selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            selectAllToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            selectAllToolStripMenuItem.Text = "Выделить все";
            selectAllToolStripMenuItem.Click += selectAllToolStripMenuItem_Click;
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { formulationToolStripMenuItem, grammarToolStripMenuItem, grammarClassificationToolStripMenuItem, analysisMethodToolStripMenuItem, errorNeutralizationToolStripMenuItem, testCaseToolStripMenuItem, bibliographyToolStripMenuItem });
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new System.Drawing.Size(48, 20);
            toolStripMenuItem3.Text = "Текст";
            // 
            // formulationToolStripMenuItem
            // 
            formulationToolStripMenuItem.Name = "formulationToolStripMenuItem";
            formulationToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            formulationToolStripMenuItem.Text = "Постановка задачи";
            formulationToolStripMenuItem.Click += formulationToolStripMenuItem_Click;
            // 
            // grammarToolStripMenuItem
            // 
            grammarToolStripMenuItem.Name = "grammarToolStripMenuItem";
            grammarToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            grammarToolStripMenuItem.Text = "Грамматика";
            grammarToolStripMenuItem.Click += grammarToolStripMenuItem_Click;
            // 
            // grammarClassificationToolStripMenuItem
            // 
            grammarClassificationToolStripMenuItem.Name = "grammarClassificationToolStripMenuItem";
            grammarClassificationToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            grammarClassificationToolStripMenuItem.Text = "Классификация грамматики";
            grammarClassificationToolStripMenuItem.Click += grammarClassificationToolStripMenuItem_Click;
            // 
            // analysisMethodToolStripMenuItem
            // 
            analysisMethodToolStripMenuItem.Name = "analysisMethodToolStripMenuItem";
            analysisMethodToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            analysisMethodToolStripMenuItem.Text = "Метод анализа";
            analysisMethodToolStripMenuItem.Click += analysisMethodToolStripMenuItem_Click;
            // 
            // errorNeutralizationToolStripMenuItem
            // 
            errorNeutralizationToolStripMenuItem.Name = "errorNeutralizationToolStripMenuItem";
            errorNeutralizationToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            errorNeutralizationToolStripMenuItem.Text = "Диагностика и нейтрализация ошибок";
            errorNeutralizationToolStripMenuItem.Click += errorNeutralizationToolStripMenuItem_Click;
            // 
            // testCaseToolStripMenuItem
            // 
            testCaseToolStripMenuItem.Name = "testCaseToolStripMenuItem";
            testCaseToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            testCaseToolStripMenuItem.Text = "Тестовый пример";
            testCaseToolStripMenuItem.Click += testCaseToolStripMenuItem_Click;
            // 
            // bibliographyToolStripMenuItem
            // 
            bibliographyToolStripMenuItem.Name = "bibliographyToolStripMenuItem";
            bibliographyToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
            bibliographyToolStripMenuItem.Text = "Список литературы";
            bibliographyToolStripMenuItem.Click += bibliographyToolStripMenuItem_Click;
            // 
            // toolStripMenuItem5
            // 
            toolStripMenuItem5.Name = "toolStripMenuItem5";
            toolStripMenuItem5.Size = new System.Drawing.Size(46, 20);
            toolStripMenuItem5.Text = "Пуск";
            // 
            // toolStripMenuItem4
            // 
            toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { callHelpToolStripMenuItem, aboutProgramToolStripMenuItem });
            toolStripMenuItem4.Name = "toolStripMenuItem4";
            toolStripMenuItem4.Size = new System.Drawing.Size(65, 20);
            toolStripMenuItem4.Text = "Справка";
            // 
            // callHelpToolStripMenuItem
            // 
            callHelpToolStripMenuItem.Name = "callHelpToolStripMenuItem";
            callHelpToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            callHelpToolStripMenuItem.Text = "Вызов справки";
            callHelpToolStripMenuItem.Click += callHelpToolStripMenuItem_Click;
            // 
            // aboutProgramToolStripMenuItem
            // 
            aboutProgramToolStripMenuItem.Name = "aboutProgramToolStripMenuItem";
            aboutProgramToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            aboutProgramToolStripMenuItem.Text = "О программе";
            aboutProgramToolStripMenuItem.Click += aboutProgramToolStripMenuItem_Click;
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { createFileButton, openFileButton, saveFileButton, cancelChangeButton, repeatLastChangeButton, copyTextButton, cutTextButton, insertTextButton, runParserButton, informationButton, createdByButton });
            toolStrip1.Location = new System.Drawing.Point(0, 24);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new System.Drawing.Size(836, 47);
            toolStrip1.TabIndex = 3;
            toolStrip1.Text = "toolStrip1";
            // 
            // createFileButton
            // 
            createFileButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            createFileButton.Image = Properties.Resources.doc;
            createFileButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            createFileButton.Name = "createFileButton";
            createFileButton.Size = new System.Drawing.Size(44, 44);
            createFileButton.Text = "Создать";
            createFileButton.Click += createFileButton_Click;
            // 
            // openFileButton
            // 
            openFileButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            openFileButton.Image = Properties.Resources.folder;
            openFileButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            openFileButton.Name = "openFileButton";
            openFileButton.Size = new System.Drawing.Size(44, 44);
            openFileButton.Text = "Открыть";
            openFileButton.Click += openFileButton_Click;
            // 
            // saveFileButton
            // 
            saveFileButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            saveFileButton.Image = Properties.Resources.save;
            saveFileButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            saveFileButton.Name = "saveFileButton";
            saveFileButton.Size = new System.Drawing.Size(44, 44);
            saveFileButton.Text = "Сохранить";
            saveFileButton.Click += saveFileButton_Click;
            // 
            // cancelChangeButton
            // 
            cancelChangeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            cancelChangeButton.Image = Properties.Resources.left;
            cancelChangeButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            cancelChangeButton.Name = "cancelChangeButton";
            cancelChangeButton.Size = new System.Drawing.Size(44, 44);
            cancelChangeButton.Text = "Отменить";
            cancelChangeButton.Click += cancelChangeButton_Click;
            // 
            // repeatLastChangeButton
            // 
            repeatLastChangeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            repeatLastChangeButton.Image = Properties.Resources.right;
            repeatLastChangeButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            repeatLastChangeButton.Name = "repeatLastChangeButton";
            repeatLastChangeButton.Size = new System.Drawing.Size(44, 44);
            repeatLastChangeButton.Text = "Повторить";
            repeatLastChangeButton.Click += repeatLastChangeButton_Click;
            // 
            // copyTextButton
            // 
            copyTextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            copyTextButton.Image = Properties.Resources.copy;
            copyTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            copyTextButton.Name = "copyTextButton";
            copyTextButton.Size = new System.Drawing.Size(44, 44);
            copyTextButton.Text = "Копировать";
            copyTextButton.Click += copyTextButton_Click;
            // 
            // cutTextButton
            // 
            cutTextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            cutTextButton.Image = Properties.Resources.cut;
            cutTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            cutTextButton.Name = "cutTextButton";
            cutTextButton.Size = new System.Drawing.Size(44, 44);
            cutTextButton.Text = "Вырезать";
            cutTextButton.Click += cutTextButton_Click;
            // 
            // insertTextButton
            // 
            insertTextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            insertTextButton.Image = Properties.Resources.paste;
            insertTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            insertTextButton.Name = "insertTextButton";
            insertTextButton.Size = new System.Drawing.Size(44, 44);
            insertTextButton.Text = "Вставить";
            insertTextButton.Click += insertTextButton_Click;
            // 
            // runParserButton
            // 
            runParserButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            runParserButton.Image = Properties.Resources.start;
            runParserButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            runParserButton.Name = "runParserButton";
            runParserButton.Size = new System.Drawing.Size(44, 44);
            runParserButton.Text = "Пуск";
            runParserButton.Click += runParserButton_Click_1;
            // 
            // informationButton
            // 
            informationButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            informationButton.Image = Properties.Resources.question;
            informationButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            informationButton.Name = "informationButton";
            informationButton.Size = new System.Drawing.Size(44, 44);
            informationButton.Text = "Вызов справки";
            informationButton.Click += informationButton_Click;
            // 
            // createdByButton
            // 
            createdByButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            createdByButton.Image = Properties.Resources.information2;
            createdByButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            createdByButton.Name = "createdByButton";
            createdByButton.Size = new System.Drawing.Size(44, 44);
            createdByButton.Text = "О программе";
            createdByButton.Click += createdByButton_Click;
            // 
            // splitContainer1
            // 
            splitContainer1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            splitContainer1.Location = new System.Drawing.Point(10, 100);
            splitContainer1.Margin = new System.Windows.Forms.Padding(2);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(editingTextBox);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(lexemeTable);
            splitContainer1.Panel2.Controls.Add(outputTextBox);
            splitContainer1.Size = new System.Drawing.Size(816, 365);
            splitContainer1.SplitterDistance = 180;
            splitContainer1.SplitterWidth = 3;
            splitContainer1.TabIndex = 4;
            // 
            // editingTextBox
            // 
            editingTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            editingTextBox.Location = new System.Drawing.Point(0, 0);
            editingTextBox.Margin = new System.Windows.Forms.Padding(2);
            editingTextBox.Name = "editingTextBox";
            editingTextBox.Size = new System.Drawing.Size(816, 180);
            editingTextBox.TabIndex = 0;
            editingTextBox.Text = "";
            // 
            // lexemeTable
            // 
            lexemeTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            lexemeTable.Dock = System.Windows.Forms.DockStyle.Fill;
            lexemeTable.Location = new System.Drawing.Point(0, 0);
            lexemeTable.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            lexemeTable.Name = "lexemeTable";
            lexemeTable.Size = new System.Drawing.Size(816, 182);
            lexemeTable.TabIndex = 5;
            // 
            // outputTextBox
            // 
            outputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            outputTextBox.Location = new System.Drawing.Point(0, 0);
            outputTextBox.Margin = new System.Windows.Forms.Padding(2);
            outputTextBox.Name = "outputTextBox";
            outputTextBox.ReadOnly = true;
            outputTextBox.Size = new System.Drawing.Size(816, 182);
            outputTextBox.TabIndex = 0;
            outputTextBox.Text = "";
            // 
            // fixButton
            // 
            fixButton.Location = new System.Drawing.Point(502, 24);
            fixButton.Name = "fixButton";
            fixButton.Size = new System.Drawing.Size(107, 47);
            fixButton.TabIndex = 5;
            fixButton.Text = "Исправить";
            fixButton.UseVisualStyleBackColor = true;
            fixButton.Click += fixButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(836, 502);
            Controls.Add(fixButton);
            Controls.Add(splitContainer1);
            Controls.Add(toolStrip1);
            Controls.Add(menuStrip1);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            MainMenuStrip = menuStrip1;
            Margin = new System.Windows.Forms.Padding(2);
            Name = "Form1";
            Text = "Компилятор";
            FormClosed += Form1_FormClosed;
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)lexemeTable).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem createToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cancelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem repeatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem formulationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grammarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grammarClassificationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem analysisMethodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem errorNeutralizationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testCaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bibliographyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem callHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutProgramToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton createFileButton;
        private System.Windows.Forms.ToolStripButton openFileButton;
        private System.Windows.Forms.ToolStripButton saveFileButton;
        private System.Windows.Forms.ToolStripButton cancelChangeButton;
        private System.Windows.Forms.ToolStripButton repeatLastChangeButton;
        private System.Windows.Forms.ToolStripButton copyTextButton;
        private System.Windows.Forms.ToolStripButton cutTextButton;
        private System.Windows.Forms.ToolStripButton insertTextButton;
        private System.Windows.Forms.ToolStripButton runParserButton;
        private System.Windows.Forms.ToolStripButton informationButton;
        private System.Windows.Forms.ToolStripButton createdByButton;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox editingTextBox;
        private System.Windows.Forms.RichTextBox outputTextBox;
        private System.Windows.Forms.DataGridView lexemeTable;
        private System.Windows.Forms.Button fixButton;
    }
}

